# Visualizing-and-Understanding-Convolutional-Networks
Pytorch implementation of deep learning research paper titled Visualizing and Understanding Convolutional Networks by M.D. Zeller and R. Fergus. 
https://arxiv.org/abs/1311.2901


To do: Address the issue of noisy output when activation maps of later layers are provided as input to deconvnet. 
